import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Переключатель Radiobutton")
    root.geometry("300x150")

    selected_option = tk.StringVar(value="Python")
    options = ["Python", "C++", "C#"]

    for option in options:
        radio = tk.Radiobutton(
            root,
            text=option,
            variable=selected_option,
            value=option,
        )
        radio.pack(anchor="w", padx=20, pady=5)

    root.mainloop()


if __name__ == "__main__":
    main()
