import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk


BASE_DIR = Path(__file__).resolve().parent

DEMOS = [
    ("01. Окно приложения (Tk)", "01_окно.py"),
    ("02. Метка (Label)", "02_метка.py"),
    ("03. Кнопка (Button)", "03_кнопка.py"),
    ("04. Однострочное поле (Entry)", "04_поле_ввода.py"),
    ("05. Флажок (Checkbutton)", "05_флажок.py"),
    ("06. Переключатель (Radiobutton)", "06_переключатель.py"),
    ("07. Список (Listbox)", "07_список.py"),
    ("08. Полоса прокрутки (Scrollbar)", "08_прокрутка.py"),
    ("09. Ползунок (Scale)", "09_ползунок.py"),
    ("10. Счётчик (Spinbox)", "10_счетчик.py"),
    ("11. Рамка (Frame)", "11_рамка.py"),
    ("12. Рамка с заголовком (LabelFrame)", "12_рамка_с_заголовком.py"),
    ("13. Холст (Canvas)", "13_холст.py"),
    ("14. Меню (Menu)", "14_меню.py"),
    ("15. Дочернее окно (Toplevel)", "15_дочернее_окно.py"),
    ("16. Вкладки (ttk.Notebook)", "16_вкладки.py"),
    ("17. Индикатор выполнения (Progressbar)", "17_индикатор.py"),
    ("18. Выпадающий список (Combobox)", "18_выпадающий_список.py"),
    ("19. Таблица (ttk.Treeview)", "19_таблица.py"),
]


def main():
    root = tk.Tk()
    root.title("Примеры Tkinter")
    root.geometry("500x540")
    root.minsize(420, 400)

    ttk.Label(
        root,
        text="Выберите программу из презентации:",
        font=("Arial", 13, "bold"),
    ).pack(padx=15, pady=(15, 10), anchor="w")

    list_frame = ttk.Frame(root)
    list_frame.pack(fill="both", expand=True, padx=15)

    scrollbar = ttk.Scrollbar(list_frame, orient="vertical")
    demo_list = tk.Listbox(
        list_frame,
        yscrollcommand=scrollbar.set,
        font=("Arial", 11),
        activestyle="dotbox",
    )
    scrollbar.config(command=demo_list.yview)
    demo_list.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    for title, _ in DEMOS:
        demo_list.insert(tk.END, title)
    demo_list.selection_set(0)

    status_var = tk.StringVar(value="Двойной щелчок также запускает пример.")
    ttk.Label(root, textvariable=status_var).pack(padx=15, pady=8, anchor="w")

    def open_demo(event=None):
        selection = demo_list.curselection()
        if not selection:
            status_var.set("Сначала выберите пример.")
            return

        title, filename = DEMOS[selection[0]]
        script_path = BASE_DIR / filename
        try:
            subprocess.Popen([sys.executable, str(script_path)])
            status_var.set(f"Запущено: {title}")
        except OSError as error:
            status_var.set(f"Ошибка запуска: {error}")

    ttk.Button(root, text="Запустить", command=open_demo).pack(pady=(0, 15))
    demo_list.bind("<Double-Button-1>", open_demo)
    demo_list.bind("<Return>", open_demo)

    root.mainloop()


if __name__ == "__main__":
    main()
