import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Счётчик Spinbox")
    root.geometry("300x120")

    months_spin = tk.Spinbox(
        root,
        values=("Сентябрь", "Октябрь", "Ноябрь"),
        wrap=True,
        justify="center",
        font=("Arial", 12),
    )
    months_spin.pack(pady=20)

    root.mainloop()


if __name__ == "__main__":
    main()
