import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Дочернее окно Toplevel")
    root.geometry("300x180")

    def open_settings():
        settings_win = tk.Toplevel(root)
        settings_win.title("Настройки")
        settings_win.geometry("200x150")
        settings_win.grab_set()

        tk.Label(settings_win, text="Окно настроек").pack(pady=30)

    open_button = tk.Button(root, text="Открыть", command=open_settings)
    open_button.pack(pady=50)

    root.mainloop()


if __name__ == "__main__":
    main()
