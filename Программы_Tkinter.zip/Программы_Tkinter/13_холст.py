import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Холст Canvas")
    root.geometry("320x240")

    canvas = tk.Canvas(root, width=300, height=200, bg="white")
    canvas.pack(pady=10)

    canvas.create_line(0, 0, 300, 200, fill="red", width=2)
    canvas.create_rectangle(50, 50, 150, 150, fill="blue")
    canvas.create_oval(180, 70, 260, 150, fill="green")

    root.mainloop()


if __name__ == "__main__":
    main()
