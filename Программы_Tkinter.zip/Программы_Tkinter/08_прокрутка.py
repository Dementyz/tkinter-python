import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Полоса прокрутки Scrollbar")
    root.geometry("300x220")

    frame = tk.Frame(root)
    frame.pack(pady=10)

    scrollbar = tk.Scrollbar(frame, orient="vertical")
    listbox = tk.Listbox(frame, yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)

    scrollbar.pack(side="right", fill="y")
    listbox.pack(side="left")

    for number in range(1, 31):
        listbox.insert(tk.END, f"Элемент {number}")

    root.mainloop()


if __name__ == "__main__":
    main()
