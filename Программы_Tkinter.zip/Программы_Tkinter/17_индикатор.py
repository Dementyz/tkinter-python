import tkinter as tk
from tkinter import ttk


def main():
    root = tk.Tk()
    root.title("Индикатор выполнения Progressbar")
    root.geometry("300x130")

    progress = ttk.Progressbar(
        root,
        orient="horizontal",
        length=200,
        mode="determinate",
        maximum=100,
    )
    progress.pack(pady=20)
    progress["value"] = 90

    ttk.Label(root, text="Выполнено: 90%").pack()

    root.mainloop()


if __name__ == "__main__":
    main()
