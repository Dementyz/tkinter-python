import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Однострочное поле Entry")
    root.geometry("300x150")

    def show_text():
        print("Текст:", user_entry.get())

    user_entry = tk.Entry(root, width=25, font=("Arial", 12))
    user_entry.pack(pady=20)

    submit_btn = tk.Button(root, text="Показать", command=show_text)
    submit_btn.pack()

    root.mainloop()


if __name__ == "__main__":
    main()
