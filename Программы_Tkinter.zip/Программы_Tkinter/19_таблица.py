import tkinter as tk
from tkinter import ttk


def main():
    root = tk.Tk()
    root.title("Таблица ttk.Treeview")
    root.geometry("350x200")

    columns = ("name", "age")
    tree = ttk.Treeview(root, columns=columns, show="headings")
    tree.heading("name", text="Имя")
    tree.heading("age", text="Возраст")
    tree.column("name", width=180)
    tree.column("age", width=80, anchor="center")

    tree.insert("", tk.END, values=("Иван", 20))
    tree.insert("", tk.END, values=("Анна", 21))
    tree.pack(fill="both", expand=True, padx=10, pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()
