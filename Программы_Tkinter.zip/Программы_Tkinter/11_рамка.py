import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Рамка Frame")
    root.geometry("300x120")

    top_frame = tk.Frame(root, bd=2, relief="groove", padx=10, pady=10)
    top_frame.pack(pady=20)

    left_button = tk.Button(top_frame, text="Левая")
    left_button.pack(side="left", padx=5)

    right_button = tk.Button(top_frame, text="Правая")
    right_button.pack(side="left", padx=5)

    root.mainloop()


if __name__ == "__main__":
    main()
