import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Рамка с заголовком LabelFrame")
    root.geometry("300x150")

    settings_group = tk.LabelFrame(
        root,
        text="Настройки звука",
        padx=10,
        pady=10,
        labelanchor="nw",
    )
    settings_group.pack(pady=20, fill="both", expand=True, padx=15)

    effects_check = tk.Checkbutton(settings_group, text="Включить эффекты")
    effects_check.pack(anchor="w")

    root.mainloop()


if __name__ == "__main__":
    main()
