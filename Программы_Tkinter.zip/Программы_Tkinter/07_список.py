import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Список Listbox")
    root.geometry("300x200")

    my_listbox = tk.Listbox(root, selectmode="single")
    my_listbox.pack(pady=10)

    languages = ["Python", "C++", "Java"]
    for language in languages:
        my_listbox.insert(tk.END, language)

    root.mainloop()


if __name__ == "__main__":
    main()
