import tkinter as tk


def on_scale(value):
    print(f"Значение: {value}")


def main():
    root = tk.Tk()
    root.title("Ползунок Scale")
    root.geometry("300x150")

    volume_scale = tk.Scale(
        root,
        from_=0,
        to=100,
        orient=tk.HORIZONTAL,
        command=on_scale,
    )
    volume_scale.pack(pady=30, fill="x", padx=20)

    root.mainloop()


if __name__ == "__main__":
    main()
