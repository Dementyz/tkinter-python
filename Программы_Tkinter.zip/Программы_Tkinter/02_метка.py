import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Метка Label")
    root.geometry("300x100")

    welcome_label = tk.Label(
        root,
        text="Привет, студенты!",
        font=("Helvetica", 16),
        fg="blue",
    )
    welcome_label.pack(pady=20)

    root.mainloop()


if __name__ == "__main__":
    main()
