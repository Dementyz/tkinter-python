import tkinter as tk
from tkinter import ttk


def main():
    root = tk.Tk()
    root.title("Выпадающий список Combobox")
    root.geometry("300x120")

    combo = ttk.Combobox(
        root,
        values=["Москва", "Санкт-Петербург"],
        state="readonly",
    )
    combo.current(0)
    combo.pack(pady=20)

    combo.bind(
        "<<ComboboxSelected>>",
        lambda event: print("Выбран город:", combo.get()),
    )

    root.mainloop()


if __name__ == "__main__":
    main()
