import tkinter as tk
from tkinter import ttk


def main():
    root = tk.Tk()
    root.title("Вкладки ttk.Notebook")
    root.geometry("350x200")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True)

    main_tab = ttk.Frame(notebook)
    settings_tab = ttk.Frame(notebook)
    notebook.add(main_tab, text="Основное")
    notebook.add(settings_tab, text="Настройки")

    ttk.Label(main_tab, text="Содержимое основной вкладки").pack(pady=20)
    ttk.Checkbutton(settings_tab, text="Включить уведомления").pack(pady=20)

    root.mainloop()


if __name__ == "__main__":
    main()
