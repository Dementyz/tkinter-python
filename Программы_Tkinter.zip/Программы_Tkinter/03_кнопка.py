import tkinter as tk


def on_click():
    print("Кнопка нажата!")


def main():
    root = tk.Tk()
    root.title("Кнопка Button")
    root.geometry("300x100")

    my_button = tk.Button(
        root,
        text="Нажми меня",
        command=on_click,
        bg="lightgray",
    )
    my_button.pack(pady=20)

    root.mainloop()


if __name__ == "__main__":
    main()
