import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Флажок Checkbutton")
    root.geometry("300x120")

    is_checked = tk.IntVar(value=0)

    def check_status():
        print("Активен" if is_checked.get() == 1 else "Пуст")

    agree_check = tk.Checkbutton(
        root,
        text="Согласен",
        variable=is_checked,
        onvalue=1,
        offvalue=0,
        command=check_status,
    )
    agree_check.pack(pady=30)

    root.mainloop()


if __name__ == "__main__":
    main()
