import tkinter as tk


def main():
    root = tk.Tk()
    root.title("Меню Menu")
    root.geometry("350x200")

    main_menu = tk.Menu(root)
    root.config(menu=main_menu)

    file_menu = tk.Menu(main_menu, tearoff=0)
    file_menu.add_command(
        label="Новый файл",
        command=lambda: print("Создан новый файл"),
    )
    file_menu.add_separator()
    file_menu.add_command(label="Выход", command=root.destroy)
    main_menu.add_cascade(label="Файл", menu=file_menu)

    root.mainloop()


if __name__ == "__main__":
    main()
